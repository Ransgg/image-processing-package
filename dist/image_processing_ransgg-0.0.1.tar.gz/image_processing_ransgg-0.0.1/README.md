# Image Processing

## Descrição:
O package image_processing é utilizado para:
	Processinhg:
		- Histogram matching
		- Structural similarity
		- Resize image
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Instalação

Utilize o gerenciador de pacote [pip](https://pip.pypa.io/en/stable/) para instalar o image_processing

```bash
pip install image_processing
```

## Author
Guilherme M. R.

## License
[MIT](https://choosealicense.com/licenses/mit/)